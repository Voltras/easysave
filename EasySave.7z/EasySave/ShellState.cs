﻿namespace EasyCli;

public sealed class ShellState
{
    public bool Running { get; set; } = true;
}